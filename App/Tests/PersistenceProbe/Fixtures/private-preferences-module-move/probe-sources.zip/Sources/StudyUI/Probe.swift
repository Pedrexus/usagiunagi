import Foundation
import SwiftData

@main struct Probe {
  @MainActor static func main() throws {
    let args = CommandLine.arguments
    let directory = URL(fileURLWithPath: args[2], isDirectory: true)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let schema = Schema(versionedSchema: PrivatePreferencesV1.self)
    let configuration = ModelConfiguration("PrivatePreferences", schema: schema,
      url: directory.appending(path: "preferences.store"), cloudKitDatabase: .none)
    let container = try ModelContainer(for: schema, configurations: configuration)
    let context = container.mainContext
    context.autosaveEnabled = false
    let id = UUID(uuidString: "BEB4DECA-F272-45CA-8EB3-C7BEE96DE655")!
    if args[1] == "write" {
      let count = try context.fetchCount(FetchDescriptor<PrivatePreferencesV1.Change>())
      precondition(count == 0)
      context.insert(PrivatePreferencesV1.Change(field: "appearance", value: "dark", revision: 8, id: id))
      try context.save()
    }
    let rows = try context.fetch(FetchDescriptor<PrivatePreferencesV1.Change>())
    precondition(rows.count == 1)
    let row = rows[0]
    precondition(row.id == id && row.field == "appearance" && row.value == "dark" && row.revision == 8 && row.formatVersion == 1)
    let identity = try JSONEncoder().encode(row.persistentModelID)
    let receipt = directory.appending(path: "identity.json")
    if args[1] == "write" { try identity.write(to: receipt) }
    else { let saved = try JSONDecoder().decode(PersistentIdentifier.self, from: Data(contentsOf: receipt)); precondition(saved == row.persistentModelID) }
    print("PASS \(args[1]) \(String(reflecting: PrivatePreferencesV1.Change.self)) \(String(decoding: identity, as: UTF8.self))")
  }
}
