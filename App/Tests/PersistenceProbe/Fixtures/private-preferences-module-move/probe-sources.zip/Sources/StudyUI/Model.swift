import Foundation
import SwiftData
nonisolated enum PrivatePreferencesV1: VersionedSchema {
  static var versionIdentifier: Schema.Version { .init(1, 0, 0) }
  static var models: [any PersistentModel.Type] { [Change.self] }

  @Model final class Change {
    var id: UUID = UUID()
    var field: String = ""
    var value: String = ""
    var revision: Int64 = 0
    var formatVersion: Int = 1

    init(field: String, value: String, revision: Int64, id: UUID = UUID()) {
      self.field = field
      self.value = value
      self.revision = revision
      self.id = id
    }

    struct Value: Equatable, Sendable {
      let id: UUID
      let field: String
      let value: String
      let revision: Int64
      let formatVersion: Int
    }

    var snapshot: Value {
      .init(id: id, field: field, value: value, revision: revision, formatVersion: formatVersion)
    }
  }
}
