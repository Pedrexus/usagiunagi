// swift-tools-version: 6.4
import PackageDescription
let package = Package(name: "PreferenceModuleProbe", platforms: [.macOS("27.0")], targets: [
  .executableTarget(name: "StudyUI", swiftSettings: [.defaultIsolation(MainActor.self)]),
  .executableTarget(name: "Tsurukame", swiftSettings: [.defaultIsolation(MainActor.self)])
], swiftLanguageModes: [.v6])
